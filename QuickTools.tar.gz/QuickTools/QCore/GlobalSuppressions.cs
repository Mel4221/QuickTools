﻿
// This file is used by Code Analysis to maintain SuppressMessage 
// attributes that are applied to this project.
// Project-level suppressions either have no target or are given 
// a specific target and scoped to a namespace, type, member, etc.

[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Potential Code Quality Issues", "RECS0022:A catch clause that catches System.Exception and has an empty body", Justification = "<Pending>", Scope = "member", Target = "~M:QuickTools.Get.KeyNumber~System.Int32")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Potential Code Quality Issues", "RECS0117:Local variable has the same name as a member and hides it", Justification = "<Pending>", Scope = "member", Target = "~M:QuickTools.Get.InputArray(System.Object)~System.String[]")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Common Practices and Code Improvements", "RECS0060:Warns when a culture-aware 'IndexOf' call is used by default.", Justification = "<Pending>", Scope = "member", Target = "~M:QuickTools.QSettings.Load")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Potential Code Quality Issues", "RECS0022:A catch clause that catches System.Exception and has an empty body", Justification = "<Pending>", Scope = "member", Target = "~M:QuickTools.QSettings.Add(System.String,System.Object)")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Common Practices and Code Improvements", "RECS0060:Warns when a culture-aware 'IndexOf' call is used by default.", Justification = "<Pending>", Scope = "member", Target = "~M:QuickTools.QSettings.Load(System.String)")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Common Practices and Code Improvements", "RECS0060:Warns when a culture-aware 'IndexOf' call is used by default.", Justification = "<Pending>", Scope = "member", Target = "~M:QuickTools.MiniDB.Load")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Common Practices and Code Improvements", "RECS0060:Warns when a culture-aware 'IndexOf' call is used by default.", Justification = "<Pending>", Scope = "member", Target = "~M:QuickTools.MiniDB.Load(System.Object)")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Potential Code Quality Issues", "RECS0018:Comparison of floating point numbers with equality operator", Justification = "<Pending>", Scope = "member", Target = "~M:QuickTools.MiniDB.Find(System.String)~System.Collections.Generic.List{QuickTools.MiniDB.DB}")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Compiler Warnings", "RECS0081:Validate Xml docs", Justification = "<Pending>", Scope = "member", Target = "~M:QuickTools.MiniDB.Dispose")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Common Practices and Code Improvements", "RECS0060:Warns when a culture-aware 'IndexOf' call is used by default.", Justification = "<Pending>", Scope = "member", Target = "~M:QuickTools.XmlHelper.RemoveElement(System.String,System.String)")]

